#!/usr/bin/env python3
import sys, time, serial

PORT = "/dev/serial0"
BAUD = int(sys.argv[1]) if len(sys.argv) > 1 else 9600
IDLE_GAP_S = 0.20   # flush a frame if link is idle ~200 ms

def byte_to_adc12(b: int) -> int:
    # map bytes [32..95] into ~0..4095 range (same as Pico mapping)
    bucket = max(0, min(63, b - 32))
    return bucket * 65 + 32

def fmt_hex(b: bytes) -> str:
    return " ".join(f"{x:02X}" for x in b)

def main():
    ser = serial.Serial(PORT, BAUD, timeout=0.05)
    sys.stderr.write(f"Opened {PORT} @ {BAUD} 8N1\n")

    buf = bytearray()
    last = time.time()
    start = time.time()  # mark start time

    while True:
        chunk = ser.read(256)
        if chunk:
            buf.extend(chunk)

        now = time.time()
        idle = (now - last) > IDLE_GAP_S
        have_nl = b"\n" in buf

        if idle or have_nl:
            frames = buf.split(b"\n")
            for frame in frames[:-1]:
                # first non-LF/CR byte = "raw"
                raw_b = next((x for x in frame if x not in (10, 13)), None)
                if raw_b is None:
                    continue
                adc12 = byte_to_adc12(raw_b)
                duty = (adc12 * 65535) // 4095
                pct  = (duty * 100) // 65535
                hexstr = fmt_hex(frame.strip(b"\r"))

                # seconds since script started
                secs = int(now - start)
                print(f"time: {secs:9d} | {raw_b:3d} raw | ADC= {adc12:4d}  PWM%= {pct:3d} | HEX:{hexstr}")

            buf = bytearray(frames[-1])
            last = now

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
